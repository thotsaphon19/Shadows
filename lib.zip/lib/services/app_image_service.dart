// lib/services/app_image_service.dart
// โหลด URL รูปภาพจาก Firestore appConfig/images
// Flutter app ใช้รูปเหล่านี้แสดงในทุกหน้าแทน placeholder

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';

class AppImageService {
  static Map<String, String> _urls = {};
  static bool _loaded = false;

  // ── โหลด URLs จาก Firestore ──────────────────────────────
  static Future<void> init() async {
    if (_loaded) return;
    try {
      final snap = await FirebaseFirestore.instance
          .collection('appConfig').doc('images').get();
      if (snap.exists) {
        _urls = Map<String, String>.from(
          snap.data()!.map((k, v) => MapEntry(k, v.toString()))
        );
      }
      _loaded = true;
      debugPrint('AppImages loaded: ${_urls.length} images');
    } catch (e) {
      debugPrint('AppImages error: $e');
      _loaded = true;
    }
  }

  // ── reload เมื่อ admin อัปเดตรูป ─────────────────────────
  static Future<void> reload() async {
    _loaded = false;
    await init();
  }

  // ── ดึง URL ──────────────────────────────────────────────
  static String? getUrl(String key) => _urls[key];

  // ── Keys ทั้งหมด ──────────────────────────────────────────
  static const mascotMain      = 'mascot_main';
  static const mascotPremium   = 'mascot_premium';
  static const mascotHalf      = 'mascot_half';
  static const logoIcon        = 'logo_icon';
  static const homeBannerBg    = 'home_banner_bg';
  static const leaderboardBanner = 'leaderboard_banner';
  static const profileBg       = 'profile_bg';
  static const profileBalloon  = 'profile_balloon';
  static const splashBg        = 'splash_bg';
}

// ── AppImage Widget ──────────────────────────────────────────
// ใช้แทน Image.asset ทุกที่ที่ต้องการรูปจาก Admin
class AppImage extends StatelessWidget {
  final String imageKey;
  final double? width;
  final double? height;
  final BoxFit fit;
  final Widget? placeholder;

  const AppImage({
    super.key,
    required this.imageKey,
    this.width,
    this.height,
    this.fit = BoxFit.contain,
    this.placeholder,
  });

  @override
  Widget build(BuildContext context) {
    final url = AppImageService.getUrl(imageKey);

    if (url == null || url.isEmpty) {
      return placeholder ?? SizedBox(
        width: width, height: height,
        child: const Center(
          child: Icon(Icons.image_outlined, color: Color(0xFFCCCCCC), size: 32),
        ),
      );
    }

    return CachedNetworkImage(
      imageUrl: url,
      width: width,
      height: height,
      fit: fit,
      placeholder: (_, __) => SizedBox(
        width: width, height: height,
        child: const Center(
          child: CircularProgressIndicator(
            strokeWidth: 2, color: Color(0xFF2E7D32),
          ),
        ),
      ),
      errorWidget: (_, __, ___) => placeholder ?? SizedBox(
        width: width, height: height,
        child: const Center(
          child: Icon(Icons.broken_image_outlined, color: Color(0xFFCCCCCC), size: 32),
        ),
      ),
    );
  }
}
